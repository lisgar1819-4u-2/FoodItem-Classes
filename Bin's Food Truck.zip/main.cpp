/***************************************************

Bin (Quoc Dat Phung)
Teacher: Ms. Lindsay Cullum
Date: April 1, 2019

        Program that uses CLASSES to print/
        calculate price of food items on a menu.

__________________________________________________
            UML MODEL FOR CLASS
__________________________________________________
            Class Item:
                double price;
                int number;
                apstring size;
                static int totalItems;
                static double totalPrice;
                static double TIP;
                static int combo;
__________________________________________________
            Methods & Constructors:
    Item();
    Item(int c, int n);
    Item(int c, int n, apstring s);
    ~Item();

    void setCombo(int c);
    void setNum(int n);
    int getNum() const {return number;};
    void setSize(apstring s);
    apstring getSize() const {return size;};
    void calculate();
    double getPrice() const {return price;};
    double getTotalPrice() const {return totalPrice;};
    void getTIP(double tip) {TIP = tip;};
    double returnTIP() const {return TIP;};
    static int getTotalItems();
__________________________________________________

***************************************************/

#include <iostream>
using namespace std;
#include <iomanip>
#include "apstring.h"
#include "apstring.cpp"

#include "ctype.h"
#include "Item.h"

void instructions();
int main () {

//Instruction to user
instructions();

//print out two decimals only.
cout << setprecision(2);
cout.setf(ios::showpoint | ios::fixed);
cout.setf(ios::right, ios::adjustfield);

///****************** INPUT

    ///Information about Combo 1
    Item order1;
    order1.setCombo(1);         //Checks if it is combo 1, 2, or 3.
    order1.setNum(1);           //Number of Orders for Combo 1
    order1.setSize("small");    //Size for Combo 1
    order1.calculate();         //Calculates price for Combo 1


    ///Information about Combo 2 (default size: regular)
    Item order2(2, 2);          // two combo 2
    order2.calculate();         //calculates price for Combo 2

    ///Information about Combo 3
    Item order3(3, 1, "small"); //one small Combo 3.
    order3.calculate();         //Calculates price for Combo 3

    ///You Tip $5.00
    order1.getTIP(5.00);

///****************** OUTPUT (Number of order, Size, total cost of that combo)

cout << "Combo 1:" << endl;
cout << "Number of Combo 1 is = " << order1.getNum()<< endl;
cout << "Size of Combo 1 is = " << order1.getSize()<< endl;
cout << "Total Cost of Combo 1 is $" << setw(2) << order1.getPrice()<< endl;

cout << endl << "Combo 2:" << endl;
cout << "Number of Combo 2 is = " << order2.getNum()<< endl;
cout << "Size of Combo 2 is = " << order2.getSize()<< endl;
cout << "Total Cost of Combo 2 is $" << setw(2) << order2.getPrice()<< endl;

cout << endl << "Combo 3:" << endl;
cout << "Number of Combo 3 is = " << order3.getNum()<< endl;
cout << "Size of Combo 3 is = " << order3.getSize()<< endl;
cout << "Total Cost of Combo 3 is $" << setw(2) << order3.getPrice()<< endl;
cout << endl;


double costEverything;
costEverything = (order1.getTotalPrice() + order1.returnTIP())*1.12;

//total number of all combos and the total cost of everything.
cout << "Amount of TIP is $" << setw(2) << order1.returnTIP() << endl;
cout << "Total Number of items = " << order1.getTotalItems() << endl;
cout << "Total Cost of all items is $" << setw(2)
                                       << costEverything << endl;

cout << endl << endl;
return 0;
}

void instructions()
{
    cout << "Welcome to Bin's Food Truck..." << endl;
    cout << "Enter 1 --->   Combo 1 (Bacon Burger + Sushi + Coke) "<< endl;
    cout << "Enter 2 --->   Combo 2 (Roasted Ribs + Salad + Smoothie) "<< endl;
    cout << "Enter 3 --->   Combo 3 (French Fries + Water)" << endl;
    cout << "Sizes are REGULAR (adults') or SMALL (kids')" << endl;
    cout << endl;
    cout << "For demonstration purposes, you ordered..." << endl;
    cout << "   One small Combo 1" << endl;
    cout << "   Two regular Combo 2s" << endl;
    cout << "   One small Combo 3" << endl;
    cout << "   You tipped $5.00" << endl << endl;
}
