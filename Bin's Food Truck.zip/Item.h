#include "apstring.h"

class Item {

public:
///OVERLOADING CONSTRUCTORS
    Item();                            //Object item (e.g hamburger)
    Item(int c, int n);                //Object with number of items (e.g 4 hamburgers)
    Item(int c, int n, apstring s);    //Number of  items and size (e.g 4 kids' burgers)


///DESTRUCTORS
    ~Item();


///METHODS
    //Receives what type of combo it is in order to calculate the price later.
    void setCombo(int c);
    //Receives the number (e.g 4 Combo 1s)
    //In that case, n = 4;
    void setNum(int n);
    //Returns the number (e.g 4 Combo 1s.
    int getNum() const {return number;};
    //Receives the size
    void setSize(apstring s);
    apstring getSize() const {return size;};
    //Calculate Price of that Combo.
    void calculate();
    //Return Price of that Combo.
    double getPrice() const {return price;};
    //Return Price of all Combos.
    double getTotalPrice() const {return totalPrice;};
    //Amount of tip
    void getTIP(double tip) {TIP = tip;};     //example of mutators
    double returnTIP() const {return TIP;};   //example of accessors.


///STATIC METHODS
    //How many Combos did you order?
    static int getTotalItems();

private:
///STATIC VARIABLES
    static int totalItems;
    static double totalPrice;
    static double TIP;
    //Combo 1, 2, or 3.
    static int combo;


///INSTANCE VARIABLES
    //Price of a Combo
    double price;
    //Number of a combo (e.g 4 Combo 1s)
    int number;
    //What size is it?
    apstring size;

};
