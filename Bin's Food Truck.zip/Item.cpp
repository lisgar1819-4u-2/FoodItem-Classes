#include <iostream>
using namespace std;

#include "Item.h"
#include <cmath>

int Item::totalItems = 0;
double Item::totalPrice = 0.0;
int Item::combo = 0;
double Item::TIP = 0.00;

///DEFINITIONS OF CONSTRUCTORS
Item::Item() {
    size = "REGULAR";
    //number and combo
    //are declared
    // with seperate methods
}

Item::Item(int c, int n){
    size = "REGULAR";
    number = n;
    combo = c;
}

Item::Item(int c, int n, apstring s){
    size = s;
    number = n;
    combo = c;
}

Item::~Item() {
    cout << "Deleting Item..." << endl;
    totalItems--;
}

///METHODS
void Item::setCombo(int c) {
    combo = c;
}

void Item::setNum(int n) {
    number = n;
}

void Item::setSize(apstring s) {
    size = s;
}

void Item::calculate() {
    size = size.substr(0,1);

if (combo == 1 ){
    if (size == "R" || size == "r")
    {
        price = double(number) * 5.00;
        size = "REGULAR";
    }

    if (size == "S" || size == "s")
    {
        price = double(number) * 4.00;
        size = "SMALL";
    }
}
if (combo == 2 ){
    if (size == "R" || size == "r")
    {
        price = double(number) * 3.00;
        size = "REGULAR";
    }

    if (size == "S" || size == "s")
    {
        price = double(number) * 2.00;
        size = "SMALL";
    }
}

if (combo == 3 ){
    if (size == "R" || size == "r")
    {
        price = double(number) * 1.00;
        size = "REGULAR";
    }

    if (size == "S" || size == "s")
    {
        price = double(number) * 0.50;
        size = "SMALL";
    }
}

    totalPrice+=price;
    totalItems+=number;
}


int Item::getTotalItems(){
return totalItems;
}




